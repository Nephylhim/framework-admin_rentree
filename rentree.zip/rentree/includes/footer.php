<hr>
<footer>
<div class="texte" align="left">
  &copy; ISEN Bretagne (<?php echo Date("Y"); ?>)
  &nbsp;-&nbsp;Contact : <a href="mailto:jean-pierre.gerval@isen-bretagne.fr?subject=Documents de rentrée">jean-pierre.gerval@isen-bretagne.fr</a>
</div>
</footer>



