<?php
define('TEST_LIB_B', true);
?>