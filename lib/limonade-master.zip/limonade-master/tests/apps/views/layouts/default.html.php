<html>
<head>
	<title>Page title</title>
</head>
<body>
	<?php echo $content?>
</body>
</html>